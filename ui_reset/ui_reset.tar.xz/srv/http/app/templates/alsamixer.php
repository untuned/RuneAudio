<div class="container">
    <h1>ALSA Configuration</h1>
    <?php
      print_r($this->alsa_controls);
    ?> 
</div>
